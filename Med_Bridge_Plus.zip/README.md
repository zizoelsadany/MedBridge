# 🏥 Med Bridge+ | Complete Digital Medical Hub

**Med Bridge+** is a state-of-the-art, responsive, and accessible digital library designed for medical students, healthcare professionals, and researchers worldwide.

Built using **Next.js 15 (App Router)**, **React 19**, **TypeScript**, **Tailwind CSS**, **Framer Motion**, and **MongoDB / Mongoose**, ready for instant **Vercel** deployment out of the box.

---

## ✨ Features & Architecture

### 🌐 No Authentication Needed
- 100% open access for visitors.
- **LocalStorage Integration**:
  - Saved Favorites (Books & Articles)
  - Ratings & Stars
  - Interactive Comments (No login required)
  - Recently Viewed & Reading Progress History
  - Dark / Light / Sepia / High Contrast Theme selection
  - English (LTR) & Arabic (RTL) instant internationalization

### 📖 Medical Library & Online PDF Reader
- Interactive **PDF Reader Canvas**:
  - Zoom in / Zoom out / Reset zoom
  - Fullscreen view
  - Page navigation controls & search inside document
  - Reading Mode switcher (Light, Dark, Sepia)

### 🏥 20 Core Medical Specialties
- Anatomy, Physiology, Histology, Embryology, Biochemistry, Pharmacology, Pathology, Microbiology, Internal Medicine, Surgery, Pediatrics, Cardiology, Neurology, Dermatology, Radiology, Orthopedics, ENT, Ophthalmology, Obstetrics & Gynecology, Nursing.

### 📚 Features Included
- **Home**: Hero section, floating search, featured textbooks, latest clinical papers, most downloaded, stats counters, testimonials, and FAQs.
- **Books**: Grid/List view toggle, search bar, category & language filtering, sorting, pagination.
- **Book Detail**: Cover, overview tabs, comments, metadata, online reader link, PDF download.
- **Articles**: Peer-reviewed clinical trial summaries with read-time and author bios.
- **Videos**: HD surgical procedures & medical lectures with built-in modal player.
- **Medical Dictionary**: Instant search across medical terms, phonetics, definitions, and related terms.
- **Admin Control Panel**: Password protected (`admin`), featuring stats, adding/editing/deleting books, uploading covers/PDFs, managing comments and categories.
- **Accessibility & Elderly Mode**: Larger fonts, high visibility buttons, and responsive design across mobile, tablets, and ultra-wide screens.

---

## 🚀 How to Run Locally

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Run Development Server**:
   ```bash
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000) in your browser.

3. **To Create Zip File**:
   Run the included PowerShell script:
   ```powershell
   .\create-zip.ps1
   ```

---

## ☁️ Vercel Deployment

Deploy directly to Vercel with zero configuration required:
1. Push your repository to GitHub / GitLab / Bitbucket.
2. Import project into Vercel dashboard.
3. (Optional) Set `MONGODB_URI` environment variable if connecting to MongoDB Atlas. If omitted, Med Bridge+ automatically operates in high-performance memory fallback mode!
