import { NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import BookModel from '@/models/Book';
import { initialBooks } from '@/lib/mockData';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get('category');
  const search = searchParams.get('search');
  const language = searchParams.get('language');

  try {
    const db = await connectToDatabase();
    if (db) {
      const filter: any = {};
      if (category && category !== 'all') filter.category = category;
      if (language && language !== 'all') filter.language = language;
      if (search) {
        filter.$or = [
          { title: { $regex: search, $options: 'i' } },
          { author: { $regex: search, $options: 'i' } },
          { description: { $regex: search, $options: 'i' } },
        ];
      }
      const books = await BookModel.find(filter).sort({ createdAt: -1 });
      return NextResponse.json(books);
    }
  } catch (error) {
    console.warn('Database error, falling back to mock data:', error);
  }

  // Fallback to mock data
  let filtered = [...initialBooks];
  if (category && category !== 'all') {
    filtered = filtered.filter(b => b.category.toLowerCase() === category.toLowerCase());
  }
  if (language && language !== 'all') {
    filtered = filtered.filter(b => b.language.toLowerCase() === language.toLowerCase());
  }
  if (search) {
    const q = search.toLowerCase();
    filtered = filtered.filter(b =>
      b.title.toLowerCase().includes(q) ||
      b.author.toLowerCase().includes(q) ||
      b.description.toLowerCase().includes(q)
    );
  }
  return NextResponse.json(filtered);
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const db = await connectToDatabase();
    if (db) {
      const newBook = await BookModel.create(body);
      return NextResponse.json(newBook, { status: 201 });
    }
    const mockBook = { ...body, _id: `book-${Date.now()}` };
    return NextResponse.json(mockBook, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to create book' }, { status: 500 });
  }
}
