'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useApp } from '@/context/AppContext';
import { ThemeToggle } from './ThemeToggle';
import { LanguageToggle } from './LanguageToggle';
import {
  Stethoscope,
  Search,
  BookOpen,
  FileText,
  Grid,
  Video,
  Bookmark,
  Sliders,
  Shield,
  Menu,
  X,
  HeartPulse,
} from 'lucide-react';

export function Navbar() {
  const pathname = usePathname();
  const {
    t,
    language,
    favBookIds,
    favArticleIds,
    setQuickSearchOpen,
    setReadingSettingsOpen,
  } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const totalFavs = favBookIds.length + favArticleIds.length;

  const navLinks = [
    { href: '/', label: t('navHome'), icon: HeartPulse },
    { href: '/books', label: t('navBooks'), icon: BookOpen },
    { href: '/articles', label: t('navArticles'), icon: FileText },
    { href: '/categories', label: t('navCategories'), icon: Grid },
    { href: '/videos', label: t('navVideos'), icon: Video },
    { href: '/dictionary', label: t('navDictionary'), icon: Stethoscope },
  ];

  return (
    <>
      <header className="sticky top-0 z-40 w-full glass-panel border-b border-slate-200/80 dark:border-slate-800/80 shadow-xs transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-brand-600 via-brand-500 to-cyanBrand-500 flex items-center justify-center shadow-md group-hover:scale-105 transition-all">
              <Stethoscope className="w-6 h-6 text-white" />
            </div>
            <div>
              <span className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-1">
                Med Bridge<span className="text-brand-500 font-black">+</span>
              </span>
              <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 block -mt-1 tracking-wider uppercase">
                Digital Medical Hub
              </span>
            </div>
          </Link>

          {/* Desktop Links */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-100/60 dark:bg-slate-800/50 p-1.5 rounded-2xl border border-slate-200/50 dark:border-slate-700/50">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                    isActive
                      ? 'bg-white dark:bg-slate-800 text-brand-600 dark:text-brand-400 shadow-sm'
                      : 'text-slate-700 dark:text-slate-300 hover:text-brand-600 hover:bg-slate-200/50 dark:hover:bg-slate-700/50'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-brand-500' : 'text-slate-400'}`} />
                  <span>{link.label}</span>
                </Link>
              );
            })}
          </nav>

          {/* Actions & Utilities */}
          <div className="flex items-center gap-2">
            {/* Quick Search Button */}
            <button
              onClick={() => setQuickSearchOpen(true)}
              className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:border-brand-300 transition-all shadow-xs"
              title={t('searchPlaceholder')}
            >
              <Search className="w-4 h-4 text-brand-500" />
              <span className="hidden md:inline">{t('search')}</span>
              <kbd className="hidden lg:inline-block px-1.5 py-0.5 text-[10px] font-mono font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-slate-400">
                ⌘K
              </kbd>
            </button>

            {/* Reading Accessibility Settings */}
            <button
              onClick={() => setReadingSettingsOpen(true)}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-brand-600 transition-all"
              title={t('readingSettings')}
            >
              <Sliders className="w-4 h-4" />
            </button>

            {/* Favorites Icon */}
            <Link
              href="/books?fav=true"
              className="relative p-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-rose-500 transition-all"
              title={t('navFavorites')}
            >
              <Bookmark className="w-4 h-4" />
              {totalFavs > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white font-bold text-[10px] rounded-full flex items-center justify-center animate-pulse">
                  {totalFavs}
                </span>
              )}
            </Link>

            {/* Admin Link */}
            <Link
              href="/admin"
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-brand-600 transition-all"
              title={t('navAdmin')}
            >
              <Shield className="w-4 h-4" />
            </Link>

            {/* Language & Theme */}
            <div className="hidden sm:flex items-center gap-2">
              <LanguageToggle />
              <ThemeToggle />
            </div>

            {/* Mobile Drawer Trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden bg-slate-900/60 backdrop-blur-sm animate-fadeIn" onClick={() => setMobileMenuOpen(false)}>
          <div
            className="absolute top-0 right-0 w-4/5 max-w-sm h-full bg-white dark:bg-slate-900 p-6 shadow-2xl flex flex-col justify-between overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-2">
                  <Stethoscope className="w-6 h-6 text-brand-500" />
                  <span className="font-extrabold text-lg text-slate-900 dark:text-white">Med Bridge+</span>
                </div>
                <button onClick={() => setMobileMenuOpen(false)} className="p-2 rounded-xl text-slate-400">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-2">
                {navLinks.map((link) => {
                  const Icon = link.icon;
                  return (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-bold text-slate-700 dark:text-slate-200 hover:bg-brand-50 hover:text-brand-600 dark:hover:bg-slate-800 transition-all"
                    >
                      <Icon className="w-5 h-5 text-brand-500" />
                      <span>{link.label}</span>
                    </Link>
                  );
                })}
              </div>
            </div>

            <div className="pt-6 border-t border-slate-100 dark:border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <LanguageToggle />
              </div>
              <div className="flex items-center justify-between">
                <ThemeToggle />
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
