'use client';

import React, { useState, useEffect } from 'react';
import { Book } from '@/lib/types';
import { useApp } from '@/context/AppContext';
import {
  ZoomIn,
  ZoomOut,
  Maximize,
  Minimize,
  ChevronLeft,
  ChevronRight,
  Search,
  Download,
  Bookmark,
  Sun,
  Moon,
  BookOpen,
  ArrowRight,
  ArrowLeft,
  Printer,
} from 'lucide-react';
import Link from 'next/link';

export function PdfReader({ book }: { book: Book }) {
  const { language, t, favBookIds, toggleFavBook } = useApp();
  const [currentPage, setCurrentPage] = useState(1);
  const [zoom, setZoom] = useState(100);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [readerTheme, setReaderTheme] = useState<'light' | 'dark' | 'sepia'>('light');
  const [searchQuery, setSearchQuery] = useState('');
  const isFav = favBookIds.includes(book._id);

  const totalPages = book.pages || 120;

  const handleNextPage = () => {
    if (currentPage < totalPages) setCurrentPage(p => p + 1);
  };

  const handlePrevPage = () => {
    if (currentPage > 1) setCurrentPage(p => p - 1);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const ArrowBackIcon = language === 'ar' ? ArrowRight : ArrowLeft;
  const PageNextIcon = language === 'ar' ? ChevronLeft : ChevronRight;
  const PagePrevIcon = language === 'ar' ? ChevronRight : ChevronLeft;

  const getThemeBg = () => {
    if (readerTheme === 'dark') return 'bg-slate-950 text-slate-100 border-slate-800';
    if (readerTheme === 'sepia') return 'bg-[#fbf0d9] text-[#3d3223] border-[#e2d3b8]';
    return 'bg-white text-slate-900 border-slate-200';
  };

  return (
    <div className={`min-h-screen flex flex-col ${isFullscreen ? 'fixed inset-0 z-50 bg-slate-950' : 'bg-slate-900 text-white'}`}>
      {/* Top Controls Toolbar */}
      <header className="px-4 py-3 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4 sticky top-0 z-40 shadow-lg">
        <div className="flex items-center gap-3">
          <Link
            href={`/books/${book._id}`}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 transition-all"
          >
            <ArrowBackIcon className="w-4 h-4" />
            <span>{t('backToBooks')}</span>
          </Link>
          <div className="hidden sm:block">
            <h2 className="text-sm font-bold text-white line-clamp-1">{book.title}</h2>
            <p className="text-xs text-slate-400">{book.author}</p>
          </div>
        </div>

        {/* Page Navigation */}
        <div className="flex items-center gap-2 bg-slate-800 p-1.5 rounded-2xl border border-slate-700">
          <button
            onClick={handlePrevPage}
            disabled={currentPage <= 1}
            className="p-1.5 rounded-xl text-slate-300 hover:bg-slate-700 disabled:opacity-30"
          >
            <PagePrevIcon className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-1 text-xs font-bold px-2">
            <span>{t('page')}</span>
            <input
              type="number"
              min={1}
              max={totalPages}
              value={currentPage}
              onChange={(e) => {
                const val = parseInt(e.target.value);
                if (val >= 1 && val <= totalPages) setCurrentPage(val);
              }}
              className="w-12 text-center bg-slate-900 border border-slate-700 rounded-lg py-1 text-white font-mono text-xs focus:outline-none"
            />
            <span className="text-slate-400">{t('of')} {totalPages}</span>
          </div>

          <button
            onClick={handleNextPage}
            disabled={currentPage >= totalPages}
            className="p-1.5 rounded-xl text-slate-300 hover:bg-slate-700 disabled:opacity-30"
          >
            <PageNextIcon className="w-4 h-4" />
          </button>
        </div>

        {/* Zoom & Actions */}
        <div className="flex items-center gap-2">
          {/* Zoom controls */}
          <div className="hidden md:flex items-center gap-1 bg-slate-800 p-1.5 rounded-2xl border border-slate-700 text-xs">
            <button onClick={() => setZoom(z => Math.max(50, z - 15))} className="p-1.5 rounded-xl hover:bg-slate-700 text-slate-300">
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="px-2 font-mono font-bold">{zoom}%</span>
            <button onClick={() => setZoom(z => Math.min(200, z + 15))} className="p-1.5 rounded-xl hover:bg-slate-700 text-slate-300">
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>

          {/* Reader Theme */}
          <div className="flex items-center gap-1 bg-slate-800 p-1.5 rounded-2xl border border-slate-700">
            <button
              onClick={() => setReaderTheme('light')}
              className={`p-1.5 rounded-xl transition-all ${readerTheme === 'light' ? 'bg-white text-slate-900 shadow' : 'text-slate-400'}`}
              title="Light Reader"
            >
              <Sun className="w-4 h-4" />
            </button>
            <button
              onClick={() => setReaderTheme('sepia')}
              className={`p-1.5 rounded-xl transition-all ${readerTheme === 'sepia' ? 'bg-[#fbf0d9] text-[#3d3223] shadow' : 'text-slate-400'}`}
              title="Sepia Reader"
            >
              <BookOpen className="w-4 h-4" />
            </button>
            <button
              onClick={() => setReaderTheme('dark')}
              className={`p-1.5 rounded-xl transition-all ${readerTheme === 'dark' ? 'bg-slate-950 text-white shadow' : 'text-slate-400'}`}
              title="Dark Reader"
            >
              <Moon className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => toggleFavBook(book._id)}
            className={`p-2 rounded-xl border transition-all ${
              isFav ? 'bg-rose-600 border-rose-500 text-white' : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Bookmark className="w-4 h-4 fill-current" />
          </button>

          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 hover:bg-slate-700 transition-all"
            title={t('fullscreen')}
          >
            {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          </button>

          <a
            href={book.pdfUrl}
            download
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs shadow-md transition-all"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">{t('downloadPdf')}</span>
          </a>
        </div>
      </header>

      {/* Reader Page Stage */}
      <main className="flex-1 overflow-auto p-4 sm:p-8 flex justify-center items-start bg-slate-950/90">
        <div
          style={{ transform: `scale(${zoom / 100})`, transformOrigin: 'top center' }}
          className={`w-full max-w-4xl min-h-[850px] rounded-3xl p-8 md:p-12 shadow-2xl border transition-all duration-300 flex flex-col justify-between ${getThemeBg()}`}
        >
          {/* Header of page */}
          <div className="flex items-center justify-between pb-6 border-b border-current/10 text-xs font-semibold opacity-60">
            <span>{book.title}</span>
            <span>{book.category} • {book.author}</span>
          </div>

          {/* Page Content View */}
          <div className="my-8 space-y-6 leading-relaxed">
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">
              {language === 'ar' ? `الفصل ${currentPage}: دراسة سريرية متعمقة` : `Chapter ${currentPage}: Comprehensive Medical Review`}
            </h1>

            <p className="text-base md:text-lg">
              {language === 'ar'
                ? `تعتبر هذه الصفحة من الكتاب المرجعي (${book.title}) مدخلاً سريرياً وتطبيقياً كبيراً لقضايا التخصص في قسم (${book.category}). تهدف الدراسة لتزويد الطالب والباحث الطبي بالمعطيات الأساسية، والتشخيص التفريقي، وأساليب الرعاية السريرية المتقدمة.`
                : `This section from the gold-standard reference (${book.title}) delivers high-yield clinical insights for ${book.category}. Designed for medical students and practicing clinicians to master pathophysiology, diagnostic algorithms, and evidence-based therapeutics.`}
            </p>

            <div className="p-6 rounded-2xl bg-current/5 border border-current/10 space-y-3 my-6">
              <h3 className="font-bold text-sm uppercase tracking-wider">
                {language === 'ar' ? 'نقاط التقييم السريع واللؤلؤات السريرية (Clinical Pearls)' : 'High-Yield Clinical Pearls'}
              </h3>
              <ul className="list-disc list-inside space-y-2 text-sm opacity-90">
                <li>{language === 'ar' ? 'الربط المباشر بين التركيب التشريحي والأعراض السريرية لل مريض.' : 'Direct correlation between anatomical landmarks and patient presentation.'}</li>
                <li>{language === 'ar' ? 'البروتوكولات الأحدث المعتمدة عالمياً للتشخيص المبكر والمعالجة.' : 'Updated international consensus guidelines for early intervention.'}</li>
                <li>{language === 'ar' ? 'ملاحظات الأمان الدوائي والآثار الجانبية الحرجة.' : 'Critical pharmacotherapeutic safety margins and adverse drug reactions.'}</li>
              </ul>
            </div>

            <p className="text-sm md:text-base opacity-80">
              {language === 'ar'
                ? `استمر في تصفح الصفحات القادمة باستخدام شريط الملاحة العلوي، أو استخدم أدوات التكبير والتصغير لتعديل الرؤية حسب راحتك البصرية.`
                : `Use the navigation tools above to flip through pages, adjust zoom levels, or download the full unabridged document for offline research.`}
            </p>

            {/* Embedded PDF iframe attempt fallback */}
            <div className="mt-8 rounded-2xl overflow-hidden border border-current/20 h-[400px]">
              <iframe
                src={`${book.pdfUrl}#page=${currentPage}`}
                title="PDF Document View"
                className="w-full h-full border-none"
              />
            </div>
          </div>

          {/* Footer of page */}
          <div className="flex items-center justify-between pt-6 border-t border-current/10 text-xs font-bold opacity-60">
            <span>Med Bridge+ Digital Library</span>
            <span>{t('page')} {currentPage} {t('of')} {totalPages}</span>
          </div>
        </div>
      </main>
    </div>
  );
}
