'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { initialBooks, initialArticles, initialDictionary } from '@/lib/mockData';
import { Search, X, BookOpen, FileText, Bookmark, ArrowRight, ArrowLeft } from 'lucide-react';
import Link from 'next/link';

export function QuickSearchModal() {
  const { quickSearchOpen, setQuickSearchOpen, t, language } = useApp();
  const [query, setQuery] = useState('');

  if (!quickSearchOpen) return null;

  const filteredBooks = query.trim()
    ? initialBooks.filter(b =>
        b.title.toLowerCase().includes(query.toLowerCase()) ||
        b.author.toLowerCase().includes(query.toLowerCase()) ||
        b.category.toLowerCase().includes(query.toLowerCase())
      )
    : initialBooks.slice(0, 3);

  const filteredArticles = query.trim()
    ? initialArticles.filter(a =>
        a.title.toLowerCase().includes(query.toLowerCase()) ||
        a.author.toLowerCase().includes(query.toLowerCase())
      )
    : initialArticles.slice(0, 2);

  const filteredTerms = query.trim()
    ? initialDictionary.filter(t =>
        t.term.toLowerCase().includes(query.toLowerCase()) ||
        t.meaning.toLowerCase().includes(query.toLowerCase())
      )
    : initialDictionary.slice(0, 3);

  const ArrowIcon = language === 'ar' ? ArrowLeft : ArrowRight;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden">
        {/* Search Header */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-brand-500 shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('searchPlaceholder')}
            className="w-full bg-transparent text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none text-base font-medium"
          />
          <button
            onClick={() => setQuickSearchOpen(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-6">
          {/* Books section */}
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-brand-500" />
              {language === 'ar' ? 'الكتب الطبية' : 'Medical Textbooks'}
            </span>
            <div className="space-y-2 mt-2">
              {filteredBooks.map((book) => (
                <Link
                  key={book._id}
                  href={`/books/${book._id}`}
                  onClick={() => setQuickSearchOpen(false)}
                  className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-brand-50 hover:dark:bg-slate-800 border border-transparent hover:border-brand-200 transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-14 bg-slate-200 dark:bg-slate-700 rounded-lg overflow-hidden shrink-0">
                      <img src={book.coverImage} alt={book.title} className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-brand-600 line-clamp-1">
                        {book.title}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{book.author} • {book.category}</p>
                    </div>
                  </div>
                  <ArrowIcon className="w-4 h-4 text-slate-400 group-hover:text-brand-600 transition-all" />
                </Link>
              ))}
            </div>
          </div>

          {/* Articles section */}
          {filteredArticles.length > 0 && (
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2 flex items-center gap-2">
                <FileText className="w-4 h-4 text-cyanBrand-500" />
                {language === 'ar' ? 'المقالات السريرية' : 'Clinical Articles'}
              </span>
              <div className="space-y-2 mt-2">
                {filteredArticles.map((article) => (
                  <Link
                    key={article._id}
                    href={`/articles/${article._id}`}
                    onClick={() => setQuickSearchOpen(false)}
                    className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-cyanBrand-50 hover:dark:bg-slate-800 border border-transparent hover:border-cyanBrand-200 transition-all group"
                  >
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-cyanBrand-600 line-clamp-1">
                        {article.title}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{article.author} • {article.readTimeMinutes} min read</p>
                    </div>
                    <ArrowIcon className="w-4 h-4 text-slate-400 group-hover:text-cyanBrand-600 transition-all" />
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Terms section */}
          {filteredTerms.length > 0 && (
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2 flex items-center gap-2">
                <Bookmark className="w-4 h-4 text-emeraldBrand-500" />
                {language === 'ar' ? 'المعجم الطبي' : 'Medical Terms'}
              </span>
              <div className="space-y-2 mt-2">
                {filteredTerms.map((term) => (
                  <Link
                    key={term._id}
                    href={`/dictionary?q=${encodeURIComponent(term.term)}`}
                    onClick={() => setQuickSearchOpen(false)}
                    className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-emerald-50 hover:dark:bg-slate-800 border border-transparent hover:border-emerald-200 transition-all group"
                  >
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-emerald-600">
                        {term.term} ({term.meaning})
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">{term.description}</p>
                    </div>
                    <ArrowIcon className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition-all" />
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
