'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Language, ThemeMode, ReadingSettings, CommentItem, Book, Article } from '@/lib/types';
import { StorageManager } from '@/lib/storage';
import { translations } from '@/lib/translations';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  readingSettings: ReadingSettings;
  updateReadingSettings: (newSettings: Partial<ReadingSettings>) => void;
  favBookIds: string[];
  toggleFavBook: (id: string) => void;
  favArticleIds: string[];
  toggleFavArticle: (id: string) => void;
  userRatings: Record<string, number>;
  rateItem: (id: string, rating: number) => void;
  comments: CommentItem[];
  addComment: (targetId: string, targetType: 'book' | 'article', content: string, userName: string, rating?: number) => void;
  deleteComment: (id: string) => void;
  quickSearchOpen: boolean;
  setQuickSearchOpen: (open: boolean) => void;
  readingSettingsOpen: boolean;
  setReadingSettingsOpen: (open: boolean) => void;
  t: (key: keyof typeof translations['en']) => string;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLangState] = useState<Language>('ar');
  const [theme, setThemeState] = useState<ThemeMode>('light');
  const [readingSettings, setReadingSettingsState] = useState<ReadingSettings>({
    fontSize: 'md',
    lineHeight: 'normal',
    paragraphWidth: 'medium',
    fontFamily: 'sans',
    elderlyMode: false,
  });
  const [favBookIds, setFavBookIds] = useState<string[]>([]);
  const [favArticleIds, setFavArticleIds] = useState<string[]>([]);
  const [userRatings, setUserRatings] = useState<Record<string, number>>({});
  const [comments, setCommentsState] = useState<CommentItem[]>([]);
  const [quickSearchOpen, setQuickSearchOpen] = useState(false);
  const [readingSettingsOpen, setReadingSettingsOpen] = useState(false);

  // Initialize from LocalStorage
  useEffect(() => {
    setLangState(StorageManager.getLanguage());
    setThemeState(StorageManager.getTheme());
    setReadingSettingsState(StorageManager.getReadingSettings());
    setFavBookIds(StorageManager.getFavoriteBooks());
    setFavArticleIds(StorageManager.getFavoriteArticles());
    setUserRatings(StorageManager.getRatedItems());
    setCommentsState(StorageManager.getComments());
  }, []);

  // Update HTML tag attributes for RTL/LTR & Theme classes
  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('dir', language === 'ar' ? 'rtl' : 'ltr');
    root.setAttribute('lang', language);

    // Clean previous themes
    root.classList.remove('dark', 'theme-sepia', 'theme-high-contrast', 'elderly-mode');

    if (theme === 'dark') {
      root.classList.add('dark');
    } else if (theme === 'sepia') {
      root.classList.add('theme-sepia');
    } else if (theme === 'high-contrast') {
      root.classList.add('theme-high-contrast');
    }

    if (readingSettings.elderlyMode) {
      root.classList.add('elderly-mode');
    }
  }, [language, theme, readingSettings.elderlyMode]);

  const setLanguage = (lang: Language) => {
    setLangState(lang);
    StorageManager.setLanguage(lang);
  };

  const setTheme = (newTheme: ThemeMode) => {
    setThemeState(newTheme);
    StorageManager.setTheme(newTheme);
  };

  const updateReadingSettings = (newSettings: Partial<ReadingSettings>) => {
    setReadingSettingsState(prev => {
      const updated = { ...prev, ...newSettings };
      StorageManager.saveReadingSettings(updated);
      return updated;
    });
  };

  const toggleFavBook = (id: string) => {
    const updated = StorageManager.toggleFavoriteBook(id);
    setFavBookIds(updated);
  };

  const toggleFavArticle = (id: string) => {
    const updated = StorageManager.toggleFavoriteArticle(id);
    setFavArticleIds(updated);
  };

  const rateItem = (id: string, rating: number) => {
    const updated = StorageManager.rateItem(id, rating);
    setUserRatings(updated);
  };

  const addComment = (targetId: string, targetType: 'book' | 'article', content: string, userName: string, rating?: number) => {
    const created = StorageManager.addComment({
      targetId,
      targetType,
      content,
      userName: userName.trim() || (language === 'ar' ? 'زائر طبيب' : 'Medical Visitor'),
      userRole: language === 'ar' ? 'طالب / طبيب' : 'Medical Scholar',
      rating
    });
    setCommentsState(prev => [created, ...prev]);
  };

  const deleteComment = (id: string) => {
    StorageManager.deleteComment(id);
    setCommentsState(prev => prev.filter(c => c._id !== id));
  };

  const t = (key: keyof typeof translations['en']): string => {
    const dict = translations[language] || translations['en'];
    return dict[key] || translations['en'][key] || key;
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        theme,
        setTheme,
        readingSettings,
        updateReadingSettings,
        favBookIds,
        toggleFavBook,
        favArticleIds,
        toggleFavArticle,
        userRatings,
        rateItem,
        comments,
        addComment,
        deleteComment,
        quickSearchOpen,
        setQuickSearchOpen,
        readingSettingsOpen,
        setReadingSettingsOpen,
        t,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
